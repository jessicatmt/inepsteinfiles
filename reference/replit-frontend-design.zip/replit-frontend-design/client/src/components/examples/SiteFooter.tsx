import SiteFooter from '../SiteFooter';

export default function SiteFooterExample() {
  return <SiteFooter />;
}
