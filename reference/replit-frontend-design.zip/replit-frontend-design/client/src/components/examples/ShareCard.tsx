import ShareCard from '../ShareCard';

export default function ShareCardExample() {
  return <ShareCard name="Michael Jordan" found={false} />;
}
