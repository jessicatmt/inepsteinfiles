import AnswerDisplay from '../AnswerDisplay';

export default function AnswerDisplayExample() {
  return <AnswerDisplay name="Michael Jordan" found={false} />;
}
