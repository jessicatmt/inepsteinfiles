import InfoSection from '../InfoSection';

export default function InfoSectionExample() {
  return <InfoSection />;
}
