import SearchInput from '../SearchInput';

export default function SearchInputExample() {
  return <SearchInput />;
}
