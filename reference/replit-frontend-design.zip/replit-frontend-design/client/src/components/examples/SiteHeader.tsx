import SiteHeader from '../SiteHeader';

export default function SiteHeaderExample() {
  return <SiteHeader />;
}
